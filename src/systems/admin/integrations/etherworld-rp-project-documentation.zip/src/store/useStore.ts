import { create } from 'zustand';

type Page = 'home' | 'rules' | 'map' | 'factions' | 'lieux' | 'join' | 'dashboard';
type Modal = null | 'login' | 'register' | 'rules-detail' | 'location-detail';

interface LocationData {
  id: string;
  name: string;
  type: 'legal' | 'illegal' | 'faction' | 'service';
  description: string;
  icon: string;
  color: string;
}

interface AppState {
  currentPage: Page;
  activeModal: Modal;
  selectedLocation: LocationData | null;
  isLoggedIn: boolean;
  username: string;
  playerRole: string;
  serverOnline: number;
  serverMax: number;
  navOpen: boolean;
  activeSection: string;
  
  setPage: (page: Page) => void;
  openModal: (modal: Modal) => void;
  closeModal: () => void;
  setSelectedLocation: (loc: LocationData | null) => void;
  login: (username: string) => void;
  logout: () => void;
  toggleNav: () => void;
  setActiveSection: (section: string) => void;
}

export const useStore = create<AppState>((set) => ({
  currentPage: 'home',
  activeModal: null,
  selectedLocation: null,
  isLoggedIn: false,
  username: '',
  playerRole: 'joueur',
  serverOnline: 47,
  serverMax: 128,
  navOpen: false,
  activeSection: 'hero',

  setPage: (page) => set({ currentPage: page, navOpen: false }),
  openModal: (modal) => set({ activeModal: modal }),
  closeModal: () => set({ activeModal: null }),
  setSelectedLocation: (loc) => set({ selectedLocation: loc }),
  login: (username) => set({ isLoggedIn: true, username }),
  logout: () => set({ isLoggedIn: false, username: '', playerRole: 'joueur' }),
  toggleNav: () => set((s) => ({ navOpen: !s.navOpen })),
  setActiveSection: (section) => set({ activeSection: section }),
}));
