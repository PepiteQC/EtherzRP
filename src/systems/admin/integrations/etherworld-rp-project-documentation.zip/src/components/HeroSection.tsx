import { useEffect, useState, useRef } from 'react';
import ThreeScene from './ThreeScene';
import { useStore } from '../store/useStore';

const words = ['IMMERSIF', 'QUÉBÉCOIS', 'RÉVOLUTIONNAIRE', 'LÉGENDAIRE'];

export default function HeroSection() {
  const { serverOnline, openModal } = useStore();
  const [wordIndex, setWordIndex] = useState(0);
  const [displayed, setDisplayed] = useState('');
  const [deleting, setDeleting] = useState(false);
  const [glitching, setGlitching] = useState(false);
  const typingRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Typing animation
  useEffect(() => {
    const word = words[wordIndex];
    
    if (!deleting && displayed.length < word.length) {
      typingRef.current = setTimeout(() => {
        setDisplayed(word.slice(0, displayed.length + 1));
      }, 80);
    } else if (!deleting && displayed.length === word.length) {
      typingRef.current = setTimeout(() => setDeleting(true), 2000);
    } else if (deleting && displayed.length > 0) {
      typingRef.current = setTimeout(() => {
        setDisplayed(displayed.slice(0, -1));
      }, 40);
    } else if (deleting && displayed.length === 0) {
      setDeleting(false);
      setWordIndex((i) => (i + 1) % words.length);
    }

    return () => { if (typingRef.current) clearTimeout(typingRef.current); };
  }, [displayed, deleting, wordIndex]);

  // Glitch on word change
  useEffect(() => {
    setGlitching(true);
    const t = setTimeout(() => setGlitching(false), 400);
    return () => clearTimeout(t);
  }, [wordIndex]);

  const scrollToJoin = () => {
    const el = document.getElementById('join');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="hero" className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden">
      {/* 3D Background */}
      <div className="absolute inset-0">
        <ThreeScene />
      </div>

      {/* Dark overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/80" />
      
      {/* Grid overlay */}
      <div className="absolute inset-0 grid-bg opacity-30" />
      
      {/* Scanlines */}
      <div className="absolute inset-0 scanlines" />

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
        
        {/* Top badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 mb-8 rounded-full bg-black/50 backdrop-blur-sm border border-purple-700/50 text-sm">
          <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
          <span className="text-green-400 font-rajdhani font-semibold tracking-widest uppercase">
            Serveur en ligne — {serverOnline} joueurs connectés
          </span>
        </div>

        {/* Main title */}
        <div className="mb-4">
          <div className={`font-orbitron font-black text-6xl sm:text-7xl md:text-8xl lg:text-9xl text-white leading-none tracking-tighter ${glitching ? 'glitch-anim' : ''}`}>
            ETHER
            <span className="gradient-text">WORLD</span>
          </div>
          <div className="font-rajdhani font-semibold text-xl sm:text-2xl text-cyan-400 tracking-[0.5em] uppercase mt-2">
            RP QUÉBEC
          </div>
        </div>

        {/* Dynamic subtitle */}
        <div className="mb-8 h-16 flex items-center justify-center">
          <div className="font-orbitron text-2xl sm:text-3xl md:text-4xl font-black">
            <span className="text-gray-400">LE ROLEPLAY </span>
            <span className={`text-purple-400 glow-text-purple typing-cursor`}>
              {displayed}
            </span>
          </div>
        </div>

        {/* Description */}
        <p className="font-rajdhani text-lg sm:text-xl text-gray-300 max-w-2xl mx-auto mb-10 leading-relaxed font-medium">
          Plonge dans l'univers le plus vivant du FiveM francophone. Québec City t'attend — 
          avec ses rues sombres, ses factions en guerre, et un monde entier à façonner selon tes choix.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16">
          <button
            onClick={scrollToJoin}
            className="btn-primary px-10 py-4 rounded-xl font-orbitron font-bold text-white tracking-widest text-sm uppercase group flex items-center gap-3"
          >
            <span>REJOINDRE LE SERVEUR</span>
            <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
            </svg>
          </button>
          
          <button
            onClick={() => openModal('register')}
            className="btn-secondary px-10 py-4 rounded-xl font-orbitron font-bold text-cyan-400 tracking-widest text-sm uppercase flex items-center gap-3"
          >
            <span>CRÉER UN COMPTE</span>
          </button>
        </div>

        {/* Stats row */}
        <div className="flex flex-wrap justify-center gap-8 sm:gap-12">
          {[
            { value: '128', label: 'Slots serveur', icon: '👥' },
            { value: '50+', label: 'Lieux uniques', icon: '🗺️' },
            { value: '5', label: 'Factions actives', icon: '⚔️' },
            { value: 'FR', label: 'Langue principale', icon: '🇨🇦' },
          ].map((stat) => (
            <div key={stat.label} className="text-center group">
              <div className="text-2xl mb-1">{stat.icon}</div>
              <div className="font-orbitron font-black text-3xl text-white glow-text-purple group-hover:text-purple-400 transition-colors">
                {stat.value}
              </div>
              <div className="text-xs text-gray-500 font-rajdhani tracking-widest uppercase mt-1">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
        <span className="text-xs text-gray-500 font-rajdhani tracking-widest uppercase">Défiler</span>
        <div className="w-6 h-10 border border-gray-600 rounded-full flex items-start justify-center p-1">
          <div className="w-1.5 h-3 bg-purple-500 rounded-full animate-bounce" />
        </div>
      </div>

      {/* Side decorations */}
      <div className="absolute left-4 top-1/2 -translate-y-1/2 hidden xl:flex flex-col gap-6 z-10">
        {['FiveM', 'RP', 'QC'].map((tag) => (
          <div key={tag} className="writing-mode-vertical text-[10px] font-orbitron text-gray-600 tracking-[0.3em]">
            {tag}
          </div>
        ))}
      </div>
    </section>
  );
}
