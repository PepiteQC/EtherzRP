import { useState, useEffect } from 'react';
import { useStore } from '../store/useStore';

const navLinks = [
  { id: 'hero', label: 'Accueil' },
  { id: 'about', label: 'À Propos' },
  { id: 'lieux', label: 'Lieux & Monde' },
  { id: 'factions', label: 'Factions' },
  { id: 'rules', label: 'Règlement' },
  { id: 'join', label: 'Rejoindre' },
];

export default function Navbar() {
  const { navOpen, toggleNav, isLoggedIn, username, serverOnline, serverMax, openModal, logout } = useStore();
  const [scrolled, setScrolled] = useState(false);
  const [activeLink, setActiveLink] = useState('hero');

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
      
      // Detect active section
      const sections = navLinks.map(l => l.id);
      for (const section of sections.reverse()) {
        const el = document.getElementById(section);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= 100) {
            setActiveLink(section);
            break;
          }
        }
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
    if (navOpen) toggleNav();
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
      scrolled ? 'bg-black/80 backdrop-blur-xl border-b border-purple-900/30' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16 md:h-20">
          
          {/* Logo */}
          <button 
            onClick={() => scrollTo('hero')}
            className="flex items-center gap-3 group"
          >
            <div className="relative w-10 h-10">
              <div className="absolute inset-0 bg-purple-600 rounded-lg rotate-45 group-hover:rotate-[225deg] transition-transform duration-700" />
              <div className="absolute inset-1 bg-cyan-500 rounded-md rotate-[22deg] group-hover:rotate-[202deg] transition-transform duration-700 opacity-60" />
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-white font-orbitron font-black text-sm">E</span>
              </div>
            </div>
            <div className="hidden sm:block">
              <div className="font-orbitron font-black text-white text-lg leading-none tracking-wider">
                ETHER<span className="text-purple-400">WORLD</span>
              </div>
              <div className="text-[10px] text-cyan-400 font-rajdhani tracking-[0.3em] uppercase">
                RP QUÉBEC
              </div>
            </div>
          </button>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => scrollTo(link.id)}
                className={`relative px-4 py-2 text-sm font-rajdhani font-semibold tracking-wider uppercase transition-all duration-300 rounded-lg group ${
                  activeLink === link.id
                    ? 'text-purple-400'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {activeLink === link.id && (
                  <span className="absolute inset-0 bg-purple-900/30 rounded-lg border border-purple-700/30" />
                )}
                <span className="relative">{link.label}</span>
              </button>
            ))}
          </div>

          {/* Right side */}
          <div className="flex items-center gap-3">
            {/* Server status */}
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/40 border border-green-800/40 text-xs">
              <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              <span className="text-green-400 font-rajdhani font-semibold">{serverOnline}/{serverMax}</span>
            </div>

            {isLoggedIn ? (
              <div className="flex items-center gap-2">
                <div className="hidden sm:flex flex-col items-end">
                  <span className="text-xs text-purple-400 font-orbitron">{username}</span>
                </div>
                <button
                  onClick={logout}
                  className="px-4 py-2 text-sm font-rajdhani font-semibold text-gray-400 hover:text-white border border-gray-700 hover:border-gray-500 rounded-lg transition-all"
                >
                  Déconnexion
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => openModal('login')}
                  className="hidden sm:block px-4 py-2 text-sm font-rajdhani font-semibold text-gray-300 hover:text-white transition-colors"
                >
                  Connexion
                </button>
                <button
                  onClick={() => openModal('register')}
                  className="btn-primary px-5 py-2 text-sm font-rajdhani font-bold text-white rounded-lg tracking-wider"
                >
                  S'INSCRIRE
                </button>
              </div>
            )}

            {/* Mobile menu toggle */}
            <button
              onClick={toggleNav}
              className="md:hidden p-2 text-gray-400 hover:text-white"
              aria-label="Menu"
            >
              <div className={`w-6 h-0.5 bg-current mb-1.5 transition-all ${navOpen ? 'rotate-45 translate-y-2' : ''}`} />
              <div className={`w-6 h-0.5 bg-current mb-1.5 transition-all ${navOpen ? 'opacity-0' : ''}`} />
              <div className={`w-6 h-0.5 bg-current transition-all ${navOpen ? '-rotate-45 -translate-y-2' : ''}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={`md:hidden transition-all duration-300 ${navOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0 overflow-hidden'}`}>
        <div className="bg-black/95 backdrop-blur-xl border-t border-purple-900/30 px-4 py-4 space-y-1">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => scrollTo(link.id)}
              className="block w-full text-left px-4 py-3 text-base font-rajdhani font-semibold tracking-wider text-gray-300 hover:text-purple-400 hover:bg-purple-900/20 rounded-lg transition-all"
            >
              {link.label}
            </button>
          ))}
          {!isLoggedIn && (
            <div className="pt-3 flex gap-2">
              <button
                onClick={() => openModal('login')}
                className="flex-1 py-2.5 text-center font-rajdhani font-semibold text-gray-300 border border-gray-700 rounded-lg"
              >
                Connexion
              </button>
              <button
                onClick={() => openModal('register')}
                className="flex-1 py-2.5 text-center font-rajdhani font-bold text-white btn-primary rounded-lg"
              >
                S'INSCRIRE
              </button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
