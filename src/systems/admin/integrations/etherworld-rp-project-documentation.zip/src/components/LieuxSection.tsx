import { useRef, useState } from 'react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

type LocationType = 'all' | 'legal' | 'illegal' | 'faction' | 'service';

const locations = [
  // Legal
  { id: 'sqdc', name: 'SQDC', category: 'legal' as const, icon: '🍃', color: '#22c55e', borderColor: 'border-green-700/40', glowColor: 'rgba(34,197,94,0.15)',
    tag: 'Commerce Officiel', desc: 'Achetez du cannabis légal, accessoires, et profitez d\'animations uniques en jeu. Stock réapprovisionné toutes les heures.', price: '$15–$60 CAD', action: 'Acheter • Fumer • Vendre' },
  { id: 'chasse-peche', name: 'Chasse & Pêche', category: 'legal' as const, icon: '🎣', color: '#84cc16', borderColor: 'border-lime-700/40', glowColor: 'rgba(132,204,22,0.15)',
    tag: 'Commerce + Job', desc: 'Équipements, permis, armes légales avec permis valide. Point de départ du job Chasseur/Pêcheur. Amendes si chasse sans permis.', price: '$50–$800 CAD', action: 'Équiper • Chasser • Pêcher' },
  { id: 'boutique-vetements', name: 'Boutique Vêtements', category: 'legal' as const, icon: '👗', color: '#f472b6', borderColor: 'border-pink-700/40', glowColor: 'rgba(244,114,182,0.15)',
    tag: 'Commerce Joueur', desc: 'Gérable par un joueur vétéran. Vêtements de marques québécoises fictives. Commandes personnalisées via RP.', price: '$80–$600 CAD', action: 'Habiller • Commander • Revendre' },
  { id: 'galeries', name: 'Galeries ETHERWORLD', category: 'legal' as const, icon: '🏬', color: '#f59e0b', borderColor: 'border-yellow-700/40', glowColor: 'rgba(245,158,11,0.15)',
    tag: 'Hub Commercial', desc: 'Centre d\'achat intérieur multi-magasins: tech, pharmacie, food court, bijouterie, salon de jeux. Parking souterrain.', price: 'Variable', action: 'Acheter • Socialiser • RP' },
  { id: 'garage', name: 'Garage Mécanique', category: 'service' as const, icon: '🔩', color: '#f97316', borderColor: 'border-orange-700/40', glowColor: 'rgba(249,115,22,0.15)',
    tag: 'Service Joueur', desc: 'Réparation, tuning visuel et performance. Achetable par un gang ou joueur riche. Jobs mécanicien disponibles.', price: '$200–$2500 CAD', action: 'Réparer • Tuner • Stocker' },
  { id: 'concessionnaire', name: 'ETHERWORLD AUTOS', category: 'service' as const, icon: '🚗', color: '#3b82f6', borderColor: 'border-blue-700/40', glowColor: 'rgba(59,130,246,0.15)',
    tag: 'Concessionnaire', desc: 'Marché automobile géré par des joueurs. Prix libres pour l\'occasion, véhicules neufs à prix fixes. Toutes catégories.', price: 'Libre', action: 'Acheter • Vendre • Négocier' },
  { id: 'station', name: 'Station-Service', category: 'service' as const, icon: '⛽', color: '#06b6d4', borderColor: 'border-cyan-700/40', glowColor: 'rgba(6,182,212,0.15)',
    tag: 'Infrastructure', desc: 'Essence obligatoire — véhicules tombent en panne sèche. Point naturel de RP et de rencontres discrètes.', price: '$40–$120 CAD', action: 'Ravitailler • Socialiser' },
  { id: 'chantier', name: 'Chantier de Construction', category: 'service' as const, icon: '🏗️', color: '#78716c', borderColor: 'border-stone-700/40', glowColor: 'rgba(120,113,108,0.15)',
    tag: 'Job Saisonnier', desc: 'Missions courtes sur tableau d\'offres. Transport, démolition, béton. Matériaux récoltés revendables.', price: '$120–$200 / mission', action: 'Travailler • Récolter' },
  // Illegal
  { id: 'labo', name: 'Laboratoire Clandestin', category: 'illegal' as const, icon: '🧪', color: '#a855f7', borderColor: 'border-purple-700/40', glowColor: 'rgba(168,85,247,0.15)',
    tag: '⚠ Lieu Secret', desc: 'Production de crystal, coke, herbe pressée. Emplacement aléatoire ou tenu par un gang. Risque de raid policier.', price: 'Profit: $$$', action: 'Produire • Livrer • Fuir' },
  { id: 'imprimerie', name: 'Imprimerie Illégale', category: 'illegal' as const, icon: '🖨️', color: '#ef4444', borderColor: 'border-red-700/40', glowColor: 'rgba(239,68,68,0.15)',
    tag: '⚠ Planque', desc: 'Faux permis, faux papiers d\'identité, fausse monnaie, faux badges. Risque élevé. Détenu par une organisation.', price: '$500–$3000 CAD', action: 'Produire • Vendre • Cacher' },
  { id: 'ferrailleur', name: 'RÉCUP ETHER', category: 'illegal' as const, icon: '♻️', color: '#84cc16', borderColor: 'border-lime-700/40', glowColor: 'rgba(132,204,22,0.15)',
    tag: '⚠ Double Identité', desc: 'Commerce légal en façade, illégal en arrière. Pièces volées, blanchiment, armes dissimulées.', price: 'Variable', action: 'Revendre • Blanchir • Stocker' },
  { id: 'marche-noir', name: 'LE SOUTERRAIN', category: 'illegal' as const, icon: '🕶️', color: '#1f2937', borderColor: 'border-gray-600/40', glowColor: 'rgba(107,114,128,0.15)',
    tag: '⚠ Lieu Rotatif', desc: 'Marché noir hebdomadaire. Position change chaque semaine. Anonymat total, commission 10%. Accès sur réputation.', price: 'Anonyme', action: 'Acheter • Vendre • Survivre' },
  { id: 'casino', name: 'L\'ÉTHER NOIR', category: 'illegal' as const, icon: '🎰', color: '#dc2626', borderColor: 'border-red-700/40', glowColor: 'rgba(220,38,38,0.15)',
    tag: '⚠ Casino Illégal', desc: 'Poker, blackjack, machines à sous. Bar ouvert, salle VIP. Lieu de deals politiques et criminels. Risque de raid.', price: 'Gains variables', action: 'Jouer • Boire • Conspirer' },
  { id: 'clinique', name: 'CLINIQUE SAINT-ELME', category: 'illegal' as const, icon: '🏥', color: '#ec4899', borderColor: 'border-pink-700/40', glowColor: 'rgba(236,72,153,0.15)',
    tag: '⚠ Médical Illégal', desc: 'Soins sans rapport de police. Chirurgie esthétique, tatouages permanents, faux certificats. Médecin RP requis.', price: '$500–$5000 CAD', action: 'Soigner • Modifier • Dissimuler' },
  // Factions
  { id: 'police', name: 'Poste de Police', category: 'faction' as const, icon: '🚔', color: '#3b82f6', borderColor: 'border-blue-700/40', glowColor: 'rgba(59,130,246,0.15)',
    tag: 'Faction Officielle', desc: 'Maintien de l\'ordre, arrestations, patrouilles. Protocoles internes stricts. Coordination avec le gouvernement.', price: 'Salaire officiel', action: 'Patrouiller • Arrêter • Protéger' },
  { id: 'hopital', name: 'Hôpital Officiel', category: 'faction' as const, icon: '🏥', color: '#22c55e', borderColor: 'border-green-700/40', glowColor: 'rgba(34,197,94,0.15)',
    tag: 'Faction EMS', desc: 'Zone Safe. Soins des blessés, réanimations, interventions d\'urgence. Aucune violence tolérée.', price: 'Salaire EMS', action: 'Soigner • Réanimer • Transporter' },
];

const filters: { id: LocationType; label: string; icon: string }[] = [
  { id: 'all', label: 'Tout', icon: '🌐' },
  { id: 'legal', label: 'Légal', icon: '🏪' },
  { id: 'service', label: 'Services', icon: '🔧' },
  { id: 'illegal', label: 'Illégal', icon: '💀' },
  { id: 'faction', label: 'Factions', icon: '⚔️' },
];

export default function LieuxSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const isVisible = useIntersectionObserver(sectionRef, { threshold: 0.05 });
  const [activeFilter, setActiveFilter] = useState<LocationType>('all');
  const [selected, setSelected] = useState<typeof locations[0] | null>(null);

  const filtered = activeFilter === 'all' ? locations : locations.filter(l => l.category === activeFilter);

  return (
    <section id="lieux" ref={sectionRef} className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-black via-[#04040e] to-black" />
      <div className="absolute inset-0 grid-bg opacity-15" />
      <div className="absolute top-1/3 right-0 w-[600px] h-[600px] bg-purple-900/10 rounded-full blur-3xl" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Header */}
        <div className={`text-center mb-16 transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-cyan-700/40 text-xs font-rajdhani text-cyan-400 tracking-widest uppercase mb-4">
            <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full" />
            LIEUX & MONDE
          </div>
          <h2 className="font-orbitron font-black text-4xl sm:text-5xl md:text-6xl text-white mb-4">
            EXPLORE <span className="gradient-text">QUÉBEC CITY</span>
          </h2>
          <p className="font-rajdhani text-xl text-gray-400 max-w-2xl mx-auto">
            Chaque coin de rue cache une opportunité. Commerces légaux, planques criminelles, factions rivales — 
            le monde t'appartient si tu as les couilles de le prendre.
          </p>
        </div>

        {/* Filters */}
        <div className={`flex flex-wrap justify-center gap-3 mb-12 transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          {filters.map((f) => (
            <button
              key={f.id}
              onClick={() => setActiveFilter(f.id)}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-full font-rajdhani font-semibold text-sm tracking-wider transition-all duration-300 ${
                activeFilter === f.id
                  ? 'bg-purple-700 text-white border border-purple-500 shadow-lg shadow-purple-900/30'
                  : 'bg-black/40 text-gray-400 border border-gray-800 hover:border-gray-600 hover:text-white'
              }`}
            >
              <span>{f.icon}</span>
              <span>{f.label}</span>
            </button>
          ))}
        </div>

        {/* Location Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filtered.map((loc, i) => (
            <button
              key={loc.id}
              onClick={() => setSelected(selected?.id === loc.id ? null : loc)}
              className={`card-hover relative p-5 rounded-2xl bg-black/60 backdrop-blur-sm border text-left transition-all duration-500 ${loc.borderColor} ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              } ${selected?.id === loc.id ? 'ring-1 ring-purple-500' : ''}`}
              style={{ 
                transitionDelay: `${i * 50}ms`,
                background: selected?.id === loc.id ? loc.glowColor : undefined
              }}
            >
              <div className="absolute inset-0 rounded-2xl opacity-0 hover:opacity-100 transition-opacity"
                style={{ background: `radial-gradient(circle at center, ${loc.glowColor} 0%, transparent 70%)` }} />
              
              <div className="relative">
                <div className="text-3xl mb-3">{loc.icon}</div>
                <div className={`inline-block text-[10px] font-rajdhani font-bold tracking-widest uppercase px-2 py-0.5 rounded-full mb-2`}
                  style={{ 
                    color: loc.color,
                    background: `${loc.color}15`,
                    border: `1px solid ${loc.color}40`
                  }}>
                  {loc.tag}
                </div>
                <h3 className="font-orbitron font-bold text-white text-sm mb-2">{loc.name}</h3>
                <p className="font-rajdhani text-gray-400 text-sm leading-relaxed line-clamp-2">{loc.desc}</p>
                
                <div className="mt-3 flex items-center justify-between">
                  <span className="text-xs font-rajdhani text-gray-500">{loc.price}</span>
                  <span className="text-xs text-purple-400 font-rajdhani">Voir plus →</span>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Selected location detail */}
        {selected && (
          <div className="mt-8 p-8 rounded-2xl bg-black/80 backdrop-blur-xl border border-purple-700/40 relative overflow-hidden transition-all">
            <div className="absolute inset-0 opacity-10"
              style={{ background: `radial-gradient(circle at top left, ${selected.glowColor}, transparent 60%)` }} />
            
            <div className="relative flex flex-col md:flex-row items-start gap-8">
              <div className="text-6xl">{selected.icon}</div>
              <div className="flex-1">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <span className="text-xs font-rajdhani font-bold tracking-widest uppercase px-3 py-1 rounded-full mb-3 inline-block"
                      style={{ color: selected.color, background: `${selected.color}15`, border: `1px solid ${selected.color}40` }}>
                      {selected.tag}
                    </span>
                    <h3 className="font-orbitron font-black text-2xl text-white mt-2">{selected.name}</h3>
                  </div>
                  <button onClick={() => setSelected(null)} className="text-gray-600 hover:text-white transition-colors text-2xl">×</button>
                </div>
                <p className="font-rajdhani text-gray-300 text-lg leading-relaxed mb-6">{selected.desc}</p>
                
                <div className="flex flex-wrap gap-4">
                  <div className="px-4 py-2 rounded-lg bg-white/5 border border-white/10">
                    <div className="text-xs text-gray-500 font-rajdhani mb-1">TARIFS</div>
                    <div className="font-orbitron font-bold text-white text-sm">{selected.price}</div>
                  </div>
                  <div className="px-4 py-2 rounded-lg bg-white/5 border border-white/10">
                    <div className="text-xs text-gray-500 font-rajdhani mb-1">ACTIONS</div>
                    <div className="font-rajdhani font-semibold text-purple-400 text-sm">{selected.action}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
