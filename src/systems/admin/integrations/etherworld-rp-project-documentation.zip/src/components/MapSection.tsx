import { useRef, useState } from 'react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

const zones = [
  { id: 'police', name: 'Poste de Police', x: 25, y: 30, color: '#3b82f6', glow: 'rgba(59,130,246,0.6)', icon: '🚔', type: 'FACTION', desc: 'Quartier général de la SPVQ. Zone sécurisée.' },
  { id: 'hospital', name: 'Hôpital Officiel', x: 70, y: 20, color: '#22c55e', glow: 'rgba(34,197,94,0.6)', icon: '🏥', type: 'SAFE ZONE', desc: 'Zone safe — EMS actif 24/7. Aucune violence tolérée.' },
  { id: 'casino', name: "L'ÉTHER NOIR", x: 60, y: 65, color: '#ef4444', glow: 'rgba(239,68,68,0.6)', icon: '🎰', type: 'ILLÉGAL', desc: 'Casino clandestin tenu par le Cartel. Accès limité.' },
  { id: 'sqdc', name: 'SQDC', x: 40, y: 45, color: '#22c55e', glow: 'rgba(34,197,94,0.5)', icon: '🍃', type: 'COMMERCIAL', desc: 'Société québécoise du cannabis. Commerce officiel.' },
  { id: 'galeries', name: 'Galeries ETHERWORLD', x: 55, y: 35, color: '#f59e0b', glow: 'rgba(245,158,11,0.5)', icon: '🏬', type: 'HUB', desc: 'Centre commercial principal. Hub social majeur.' },
  { id: 'labo', name: 'Labo Clandestin', x: 80, y: 55, color: '#a855f7', glow: 'rgba(168,85,247,0.6)', icon: '🧪', type: 'SECRET', desc: 'Emplacement rotatif. Tenu par une organisation criminelle.' },
  { id: 'garage', name: 'Garage Mécanique', x: 30, y: 60, color: '#f97316', glow: 'rgba(249,115,22,0.5)', icon: '🔩', type: 'SERVICE', desc: 'Réparation et tuning de véhicules. Commerce joueur.' },
  { id: 'souterrain', name: 'Le Souterrain', x: 45, y: 75, color: '#6b7280', glow: 'rgba(107,114,128,0.5)', icon: '🕶️', type: '⚠ ROTATIF', desc: 'Marché noir hebdomadaire. Position change chaque semaine.' },
  { id: 'station', name: 'Station-Service', x: 15, y: 50, color: '#06b6d4', glow: 'rgba(6,182,212,0.5)', icon: '⛽', type: 'INFRA', desc: 'Ravitaillement obligatoire. Point de RP naturel.' },
  { id: 'clinique', name: 'Clinique St-Elme', x: 75, y: 80, color: '#ec4899', glow: 'rgba(236,72,153,0.5)', icon: '🏥', type: '⚠ ILLÉGAL', desc: 'Soins sans rapport policier. Médecin RP requis.' },
];

export default function MapSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const isVisible = useIntersectionObserver(sectionRef, { threshold: 0.05 });
  const [activeZone, setActiveZone] = useState<typeof zones[0] | null>(null);
  const [hoveredZone, setHoveredZone] = useState<string | null>(null);

  return (
    <section ref={sectionRef} className="relative py-24 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-black via-[#030210] to-black" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Header */}
        <div className={`text-center mb-12 transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-cyan-700/40 text-xs font-rajdhani text-cyan-400 tracking-widest uppercase mb-4">
            <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full" />
            CARTE INTERACTIVE
          </div>
          <h2 className="font-orbitron font-black text-3xl sm:text-4xl md:text-5xl text-white mb-3">
            EXPLORE <span className="gradient-text">LA CARTE</span>
          </h2>
          <p className="font-rajdhani text-lg text-gray-400">
            Clique sur un marqueur pour découvrir le lieu
          </p>
        </div>

        <div className="flex flex-col xl:flex-row gap-8">
          
          {/* Map */}
          <div className={`relative flex-1 transition-all duration-1000 ${isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`}>
            <div className="relative rounded-2xl overflow-hidden border border-gray-800/60"
              style={{ aspectRatio: '16/9', background: 'linear-gradient(135deg, #030712, #050520)' }}>
              
              {/* City map image overlay */}
              <img
                src="/images/city-map.jpg"
                alt="Carte ETHERWORLD"
                className="absolute inset-0 w-full h-full object-cover opacity-50"
              />
              
              {/* Grid overlay */}
              <div className="absolute inset-0 grid-bg opacity-30" />
              
              {/* Scanline */}
              <div className="absolute inset-0 scanlines" />

              {/* Zone dots */}
              {zones.map((zone) => (
                <button
                  key={zone.id}
                  onClick={() => setActiveZone(activeZone?.id === zone.id ? null : zone)}
                  onMouseEnter={() => setHoveredZone(zone.id)}
                  onMouseLeave={() => setHoveredZone(null)}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2 group"
                  style={{ left: `${zone.x}%`, top: `${zone.y}%` }}
                >
                  {/* Pulse ring */}
                  <div className="absolute inset-0 rounded-full animate-ping opacity-30"
                    style={{ 
                      background: zone.color,
                      transform: 'scale(2)',
                      animationDuration: `${2 + Math.random() * 2}s`
                    }} />
                  
                  {/* Dot */}
                  <div className={`relative w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 text-sm ${
                    activeZone?.id === zone.id ? 'scale-125' : 'hover:scale-125'
                  }`}
                    style={{ 
                      background: `${zone.color}30`,
                      border: `2px solid ${zone.color}`,
                      boxShadow: (activeZone?.id === zone.id || hoveredZone === zone.id) ? `0 0 15px ${zone.glow}, 0 0 30px ${zone.color}40` : `0 0 8px ${zone.color}40`
                    }}>
                    <span className="text-xs">{zone.icon}</span>
                  </div>
                  
                  {/* Tooltip */}
                  {hoveredZone === zone.id && (
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 z-20 pointer-events-none">
                      <div className="bg-black/95 border border-gray-700 rounded-xl px-3 py-2 whitespace-nowrap">
                        <div className="font-orbitron font-bold text-white text-xs">{zone.name}</div>
                        <div className="font-rajdhani text-xs mt-0.5" style={{ color: zone.color }}>{zone.type}</div>
                      </div>
                      <div className="w-2 h-2 bg-black border-r border-b border-gray-700 rotate-45 mx-auto -mt-1" />
                    </div>
                  )}
                </button>
              ))}

              {/* Corner decoration */}
              <div className="absolute top-3 left-3 font-orbitron text-[10px] text-gray-600 tracking-widest">
                ETHERWORLD RP — QUÉBEC CITY
              </div>
              <div className="absolute bottom-3 right-3 font-orbitron text-[10px] text-gray-600 tracking-widest">
                MAP v1.0
              </div>
            </div>
          </div>

          {/* Zone detail */}
          <div className={`xl:w-72 flex flex-col gap-4 transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'}`}>
            
            {activeZone ? (
              <div className="p-6 rounded-2xl relative overflow-hidden"
                style={{ 
                  background: `linear-gradient(135deg, ${activeZone.color}10, #000)`,
                  border: `1px solid ${activeZone.color}30`
                }}>
                <div className="absolute top-0 right-0 w-24 h-24 rounded-full blur-2xl opacity-20"
                  style={{ background: activeZone.color }} />
                <div className="relative">
                  <div className="text-4xl mb-3">{activeZone.icon}</div>
                  <div className="text-xs font-rajdhani font-bold tracking-widest uppercase mb-1 px-2 py-0.5 rounded-full inline-block"
                    style={{ color: activeZone.color, background: `${activeZone.color}15`, border: `1px solid ${activeZone.color}30` }}>
                    {activeZone.type}
                  </div>
                  <h3 className="font-orbitron font-black text-xl text-white mt-2 mb-3">{activeZone.name}</h3>
                  <p className="font-rajdhani text-gray-400 leading-relaxed">{activeZone.desc}</p>
                  
                  <button
                    onClick={() => setActiveZone(null)}
                    className="mt-4 text-xs font-rajdhani text-gray-600 hover:text-gray-400 transition-colors"
                  >
                    ← Fermer
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-6 rounded-2xl bg-black/60 border border-gray-800/40 flex-1 flex flex-col items-center justify-center text-center">
                <div className="text-4xl mb-3">🗺️</div>
                <h3 className="font-orbitron font-bold text-white text-sm mb-2">Carte Interactive</h3>
                <p className="font-rajdhani text-gray-500 text-sm">Clique sur un marqueur pour voir les détails du lieu</p>
              </div>
            )}

            {/* Legend */}
            <div className="p-5 rounded-2xl bg-black/60 border border-gray-800/40">
              <h4 className="font-orbitron font-bold text-white text-xs mb-4 tracking-widest">LÉGENDE</h4>
              <div className="space-y-2">
                {[
                  { color: '#3b82f6', label: 'Faction Officielle' },
                  { color: '#22c55e', label: 'Safe Zone / EMS' },
                  { color: '#f59e0b', label: 'Commerce / Hub' },
                  { color: '#ef4444', label: 'Zone Criminelle' },
                  { color: '#a855f7', label: 'Lieu Secret' },
                  { color: '#06b6d4', label: 'Infrastructure' },
                ].map((item) => (
                  <div key={item.label} className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full flex-shrink-0"
                      style={{ background: item.color, boxShadow: `0 0 6px ${item.color}80` }} />
                    <span className="font-rajdhani text-xs text-gray-500">{item.label}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Zone count */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-4 rounded-xl bg-black/60 border border-gray-800/40 text-center">
                <div className="font-orbitron font-black text-2xl text-purple-400">{zones.length}</div>
                <div className="font-rajdhani text-xs text-gray-500 mt-1">Lieux marqués</div>
              </div>
              <div className="p-4 rounded-xl bg-black/60 border border-gray-800/40 text-center">
                <div className="font-orbitron font-black text-2xl text-cyan-400">50+</div>
                <div className="font-rajdhani text-xs text-gray-500 mt-1">Zones total</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
