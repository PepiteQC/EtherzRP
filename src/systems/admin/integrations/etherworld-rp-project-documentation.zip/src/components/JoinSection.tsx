import { useRef, useState } from 'react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { useStore } from '../store/useStore';

const steps = [
  { num: 1, icon: '📋', title: 'Créer un compte', desc: 'Inscris-toi sur le site avec un email valide. Ton compte sera lié à ton profil joueur.' },
  { num: 2, icon: '📖', title: 'Lire le règlement', desc: 'Assure-toi de bien comprendre les règles — l\'ignorance ne dispense pas de les respecter.' },
  { num: 3, icon: '🎭', title: 'Créer ton personnage', desc: 'Nom réaliste, histoire de fond, faction de départ. Donne vie à ton alter ego québécois.' },
  { num: 4, icon: '🎮', title: 'Installer FiveM', desc: 'Télécharge FiveM sur fivem.net, installe-le et connecte-toi avec le code serveur.' },
  { num: 5, icon: '🌆', title: 'Rejoindre le serveur', desc: 'Entre dans ETHERWORLD RP et commence ton aventure dans les rues de Québec City.' },
];

const requirements = [
  { icon: '🎂', text: '16 ans minimum' },
  { icon: '🎮', text: 'FiveM installé' },
  { icon: '🎧', text: 'Micro recommandé' },
  { icon: '🇫🇷', text: 'Parle français' },
  { icon: '📋', text: 'Règlement accepté' },
  { icon: '👤', text: 'Personnage réaliste' },
];

export default function JoinSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const isVisible = useIntersectionObserver(sectionRef, { threshold: 0.05 });
  const { openModal } = useStore();
  const [copied, setCopied] = useState(false);

  const serverCode = 'ETHERWORLD-QC';
  
  const handleCopy = () => {
    navigator.clipboard.writeText(serverCode).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section id="join" ref={sectionRef} className="relative py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-black via-[#030210] to-[#010105]" />
      <div className="absolute inset-0 grid-bg opacity-20" />
      
      {/* Dramatic glow */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-[800px] h-[800px] bg-purple-900/15 rounded-full blur-3xl" />
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-64 bg-gradient-to-t from-purple-950/20 to-transparent" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6">
        
        {/* Header */}
        <div className={`text-center mb-20 transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-purple-700/40 text-xs font-rajdhani text-purple-400 tracking-widest uppercase mb-6">
            <span className="w-1.5 h-1.5 bg-purple-400 rounded-full pulse-glow" />
            REJOINDRE ETHERWORLD
          </div>
          <h2 className="font-orbitron font-black text-4xl sm:text-6xl md:text-7xl text-white mb-6 leading-tight">
            TON AVENTURE<br />
            <span className="gradient-text">COMMENCE ICI</span>
          </h2>
          <p className="font-rajdhani text-xl text-gray-400 max-w-2xl mx-auto leading-relaxed">
            Des milliers de joueurs t'attendent dans les rues de Québec City. 
            Chaque décision compte. Chaque action a des conséquences. Es-tu prêt?
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          
          {/* Steps */}
          <div className={`lg:col-span-2 transition-all duration-700 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'}`}>
            <h3 className="font-orbitron font-black text-xl text-white mb-6 flex items-center gap-2">
              <span className="text-purple-400">📡</span> ÉTAPES POUR REJOINDRE
            </h3>
            <div className="space-y-4">
              {steps.map((step, i) => (
                <div
                  key={step.num}
                  className="flex items-start gap-5 p-5 rounded-2xl bg-black/60 backdrop-blur-sm border border-gray-800/50 hover:border-purple-700/40 transition-all duration-300 group card-hover"
                  style={{ transitionDelay: `${i * 80}ms` }}
                >
                  <div className="flex-shrink-0 w-12 h-12 rounded-xl flex items-center justify-center font-orbitron font-black text-lg bg-purple-900/30 border border-purple-700/30 group-hover:bg-purple-900/50 transition-colors">
                    {step.icon}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-1">
                      <span className="font-orbitron text-xs text-purple-400 font-bold">ÉTAPE {step.num}</span>
                    </div>
                    <h4 className="font-orbitron font-bold text-white text-sm mb-2">{step.title}</h4>
                    <p className="font-rajdhani text-gray-400 leading-relaxed">{step.desc}</p>
                  </div>
                  <div className="flex-shrink-0 w-8 h-8 rounded-full border border-gray-700 flex items-center justify-center">
                    <span className="font-orbitron font-black text-gray-600 text-xs">{step.num}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Join card */}
          <div className={`flex flex-col gap-6 transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'}`}>
            
            {/* Server info */}
            <div className="p-6 rounded-2xl bg-gradient-to-br from-purple-900/30 to-black border border-purple-700/40 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-purple-600/10 rounded-full blur-2xl" />
              <div className="relative">
                <div className="flex items-center gap-2 mb-4">
                  <span className="w-3 h-3 bg-green-400 rounded-full animate-pulse" />
                  <span className="font-rajdhani text-green-400 font-bold text-sm">SERVEUR EN LIGNE</span>
                </div>
                
                <div className="font-orbitron font-black text-2xl text-white mb-1">ETHERWORLD RP</div>
                <div className="font-rajdhani text-cyan-400 text-sm mb-6">Québec City | FiveM | Français</div>
                
                {/* Server code */}
                <div className="mb-4">
                  <div className="text-xs font-rajdhani text-gray-500 mb-2 tracking-widest uppercase">Code Serveur FiveM</div>
                  <button
                    onClick={handleCopy}
                    className="w-full flex items-center justify-between p-3 rounded-xl bg-black/60 border border-gray-700 hover:border-purple-600 transition-all group"
                  >
                    <span className="font-orbitron font-bold text-purple-400 text-sm">{serverCode}</span>
                    <span className="text-xs font-rajdhani text-gray-500 group-hover:text-purple-400 transition-colors">
                      {copied ? '✓ Copié!' : '📋 Copier'}
                    </span>
                  </button>
                </div>
                
                {/* Slots */}
                <div className="mb-6">
                  <div className="flex justify-between text-xs font-rajdhani mb-2">
                    <span className="text-gray-500">JOUEURS EN LIGNE</span>
                    <span className="text-purple-400 font-bold">47 / 128</span>
                  </div>
                  <div className="h-2 bg-gray-900 rounded-full overflow-hidden">
                    <div className="h-full rounded-full bg-gradient-to-r from-purple-600 to-cyan-500" style={{ width: '37%' }} />
                  </div>
                </div>
                
                <button
                  onClick={() => openModal('register')}
                  className="btn-primary w-full py-4 rounded-xl font-orbitron font-bold text-white tracking-widest text-sm uppercase"
                >
                  S'INSCRIRE MAINTENANT
                </button>
              </div>
            </div>

            {/* Requirements */}
            <div className="p-6 rounded-2xl bg-black/60 border border-gray-800/40">
              <h4 className="font-orbitron font-bold text-white text-sm mb-4 flex items-center gap-2">
                <span>📋</span> PRÉREQUIS
              </h4>
              <div className="grid grid-cols-2 gap-3">
                {requirements.map((req) => (
                  <div key={req.text} className="flex items-center gap-2">
                    <span className="text-base">{req.icon}</span>
                    <span className="font-rajdhani text-sm text-gray-400">{req.text}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Discord */}
            <div className="p-6 rounded-2xl bg-[#5865f2]/10 border border-[#5865f2]/30 hover:bg-[#5865f2]/15 transition-all cursor-pointer group card-hover">
              <div className="flex items-center gap-4 mb-3">
                <svg className="w-8 h-8 text-[#5865f2]" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057c.001.022.013.043.031.057a19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z"/>
                </svg>
                <div>
                  <div className="font-orbitron font-bold text-white text-sm">Discord Officiel</div>
                  <div className="font-rajdhani text-gray-400 text-xs">Support • Annonces • Communauté</div>
                </div>
              </div>
              <button className="w-full py-2.5 rounded-lg bg-[#5865f2] hover:bg-[#4752c4] font-rajdhani font-bold text-white tracking-wide transition-colors text-sm">
                REJOINDRE LE DISCORD
              </button>
            </div>
          </div>
        </div>

        {/* Final CTA */}
        <div className={`text-center transition-all duration-1000 delay-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="inline-block p-12 rounded-3xl bg-gradient-to-br from-purple-900/20 to-black border border-purple-700/30 max-w-2xl w-full">
            <div className="text-6xl mb-6">🌆</div>
            <h3 className="font-orbitron font-black text-3xl text-white mb-4">
              PRÊT À VIVRE<br />L'EXPÉRIENCE?
            </h3>
            <p className="font-rajdhani text-gray-400 text-lg mb-8 leading-relaxed">
              ETHERWORLD RP QUÉBEC t'attend. Des rues à conquérir, des factions à rejoindre, 
              une réputation à bâtir — ou détruire.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => openModal('register')}
                className="btn-primary px-10 py-4 rounded-xl font-orbitron font-bold text-white tracking-widest text-sm uppercase"
              >
                CRÉER MON COMPTE
              </button>
              <a
                href="#rules"
                onClick={(e) => {
                  e.preventDefault();
                  document.getElementById('rules')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="btn-secondary px-10 py-4 rounded-xl font-orbitron font-bold text-cyan-400 tracking-widest text-sm uppercase"
              >
                LIRE LE RÈGLEMENT
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
