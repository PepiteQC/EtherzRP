import { useState, useEffect } from 'react';
import { useStore } from '../store/useStore';

const activities = [
  { player: 'Jean_Tremblay', action: 'a rejoint la SPVQ', time: '2min', color: '#3b82f6', icon: '🚔' },
  { player: 'Marie_Lavoie', action: 'a ouvert son commerce — Boutique Mode', time: '5min', color: '#f472b6', icon: '👗' },
  { player: 'Darkstar_Québec', action: 'a été arrêté — Possession de drogues', time: '8min', color: '#ef4444', icon: '💀' },
  { player: 'Alex_Mercier', action: 'a déclenché une course-poursuite — Autoroute 40', time: '12min', color: '#f59e0b', icon: '🚗' },
  { player: 'Sophie_Bernard', action: 'rejoint l\'EMS — Grade Stagiaire', time: '15min', color: '#22c55e', icon: '🚑' },
  { player: 'Victor_Pelletier', action: 'a ouvert le Casino L\'Éther Noir', time: '20min', color: '#a855f7', icon: '🎰' },
];

const onlinePlayers = [
  { name: 'Jean_Tremblay', role: 'Agent SPVQ', faction: 'police', status: 'En patrouille' },
  { name: 'Darkstar_QC', role: 'Soldat', faction: 'criminal', status: 'Hors radar' },
  { name: 'Dr.Moreau', role: 'Médecin EMS', faction: 'ems', status: 'En service' },
  { name: 'PhilippeCote', role: 'Entrepreneur', faction: 'civil', status: 'Commerce ouvert' },
  { name: 'ShadowKing', role: 'Patron Cartel', faction: 'criminal', status: 'Réunion' },
  { name: 'Officer_Roy', role: 'Sergent', faction: 'police', status: 'Interpellation' },
  { name: 'Claire_N', role: 'Paramédic', faction: 'ems', status: 'Disponible' },
  { name: 'Marc_Villeneuve', role: 'Mécanicien', faction: 'civil', status: 'Au garage' },
];

const factionColors: Record<string, string> = {
  police: '#3b82f6',
  criminal: '#ef4444',
  ems: '#22c55e',
  civil: '#9ca3af',
};

export default function LiveDashboard() {
  const { isLoggedIn, username } = useStore();
  const [activeTab, setActiveTab] = useState<'activity' | 'players' | 'economy'>('activity');
  const [cash, setCash] = useState(2450);
  const [bank, setBank] = useState(18750);

  // Simulate economy changes
  useEffect(() => {
    const interval = setInterval(() => {
      setCash(c => Math.max(0, c + Math.floor((Math.random() - 0.3) * 200)));
      setBank(b => Math.max(0, b + Math.floor((Math.random() - 0.4) * 500)));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  if (!isLoggedIn) return null;

  return (
    <div className="fixed bottom-6 right-6 z-40 w-80 bg-black/95 backdrop-blur-xl border border-purple-700/40 rounded-2xl overflow-hidden shadow-2xl shadow-purple-900/20">
      {/* Header */}
      <div className="px-4 py-3 border-b border-gray-800/60 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
          <span className="font-orbitron font-bold text-xs text-white">{username}</span>
        </div>
        <div className="font-rajdhani text-xs text-purple-400 bg-purple-900/20 px-2 py-0.5 rounded-full">
          JOUEUR CONNECTÉ
        </div>
      </div>

      {/* Economy bar */}
      <div className="px-4 py-3 border-b border-gray-800/40 grid grid-cols-2 gap-3">
        <div>
          <div className="text-[10px] font-rajdhani text-gray-600 tracking-widest mb-0.5">LIQUIDE</div>
          <div className="font-orbitron font-bold text-green-400 text-sm">${cash.toLocaleString()} CAD</div>
        </div>
        <div>
          <div className="text-[10px] font-rajdhani text-gray-600 tracking-widest mb-0.5">BANQUE</div>
          <div className="font-orbitron font-bold text-cyan-400 text-sm">${bank.toLocaleString()} CAD</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-800/40">
        {([
          { id: 'activity', label: 'Activité' },
          { id: 'players', label: 'Joueurs' },
          { id: 'economy', label: 'Stats' },
        ] as const).map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 py-2 text-xs font-rajdhani font-semibold tracking-wider transition-colors ${
              activeTab === tab.id ? 'text-purple-400 border-b border-purple-500' : 'text-gray-500 hover:text-gray-300'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="h-56 overflow-y-auto custom-scroll">
        {activeTab === 'activity' && (
          <div className="p-3 space-y-2">
            {activities.map((act, i) => (
              <div key={i} className="flex items-start gap-2 p-2 rounded-lg hover:bg-white/5 transition-colors">
                <span className="text-base flex-shrink-0">{act.icon}</span>
                <div className="flex-1 min-w-0">
                  <span className="font-orbitron font-bold text-xs" style={{ color: act.color }}>{act.player}</span>
                  <span className="font-rajdhani text-xs text-gray-400"> {act.action}</span>
                </div>
                <span className="font-rajdhani text-[10px] text-gray-600 flex-shrink-0">il y a {act.time}</span>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'players' && (
          <div className="p-3 space-y-2">
            {onlinePlayers.map((player, i) => (
              <div key={i} className="flex items-center gap-2 p-2 rounded-lg hover:bg-white/5 transition-colors">
                <div className="w-2 h-2 rounded-full flex-shrink-0"
                  style={{ background: factionColors[player.faction] || '#9ca3af' }} />
                <div className="flex-1 min-w-0">
                  <div className="font-orbitron font-bold text-xs text-white truncate">{player.name}</div>
                  <div className="font-rajdhani text-[10px] text-gray-500">{player.status}</div>
                </div>
                <div className="font-rajdhani text-[10px] text-gray-600 truncate">{player.role}</div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'economy' && (
          <div className="p-4 space-y-4">
            {[
              { label: 'Transactions aujourd\'hui', value: '247', unit: 'opérations', color: '#22c55e' },
              { label: 'Volume total échangé', value: '$1.2M', unit: 'CAD', color: '#f59e0b' },
              { label: 'Joueurs actifs', value: '47', unit: '/ 128 slots', color: '#3b82f6' },
              { label: 'Crimes signalés', value: '12', unit: 'cette heure', color: '#ef4444' },
              { label: 'Véhicules actifs', value: '31', unit: 'en circulation', color: '#a855f7' },
            ].map((stat) => (
              <div key={stat.label}>
                <div className="flex justify-between items-center mb-1">
                  <span className="font-rajdhani text-xs text-gray-500">{stat.label}</span>
                  <div className="flex items-baseline gap-1">
                    <span className="font-orbitron font-bold text-sm" style={{ color: stat.color }}>{stat.value}</span>
                    <span className="font-rajdhani text-[10px] text-gray-600">{stat.unit}</span>
                  </div>
                </div>
                <div className="h-1 bg-gray-900 rounded-full overflow-hidden">
                  <div className="h-full rounded-full" style={{ 
                    width: `${30 + Math.random() * 60}%`,
                    background: stat.color
                  }} />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
